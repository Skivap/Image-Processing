How to Run :

1. Make sure the image name is "Image.tif"
2. Open main.m and run
3. Input the level value
4. It will show the image